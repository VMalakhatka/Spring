package org.example.exception;

public record ErrorMessage(String message) { }
